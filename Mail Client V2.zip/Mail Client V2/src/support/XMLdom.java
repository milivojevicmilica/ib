package support;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

	
public class XMLdom {
	String filePath="C:/Users/Win10/git/ib/Mail Client V2/data/XML/";
	public String filePathXML(){
		return filePath;
		
	}
	public File saveEmailToXml(String reciever,String title,String message) {
		File xmlFajl=null;
		try {

				    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				    Document doc = docBuilder.newDocument();
				    Element rootElement = doc.createElement("Mail");
				    doc.appendChild(rootElement);
				   
				    Element recieverTag = doc.createElement("Receiver");
				    recieverTag.appendChild(doc.createTextNode(reciever));
				    rootElement.appendChild(recieverTag);
				    
				    Element titleTag = doc.createElement("Title");
				    titleTag.appendChild(doc.createTextNode(title));
				    rootElement.appendChild(titleTag);
				    
				    Element messageTag = doc.createElement("Message");
				    messageTag.appendChild(doc.createTextNode(message));
				    rootElement.appendChild(messageTag);
				    
				    
				    TransformerFactory transformerFactory = TransformerFactory.newInstance();
				    Transformer transformer = transformerFactory.newTransformer();
				    DOMSource source = new DOMSource(doc);
				    StreamResult result = new StreamResult(new File(filePath+"mail.xml"));
				    transformer.transform(source, result);
				    System.out.println("File saved!");
				 
				    xmlFajl=new File(filePath+"mail.xml");
		}catch(Exception e) {
			e.printStackTrace();
			xmlFajl=null;
		}
		return xmlFajl;
	}
	
}
